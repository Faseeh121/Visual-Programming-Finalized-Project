﻿using System;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using Inventory_managment;

namespace InventoryApp
{
    public partial class LoginForm : Window
    {

        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public LoginForm()
        {
            InitializeComponent();
        }

        private void RoleComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

          
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Both username and password are required.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

           
            string hashedPassword = HashPassword(password);

            try
            {
               
                using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT COUNT(1) FROM Users WHERE Username = @Username AND PasswordHash = @PasswordHash";
                    using (var command = new Microsoft.Data.SqlClient.SqlCommand(query, connection))
                    {
                        
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@PasswordHash", hashedPassword);

                        
                        int userExists = (int)command.ExecuteScalar();

                        if (userExists > 0)
                        {/////////////////////////////////////////////////////////////////////////////////////////////////////
                            MessageBox.Show("Login successful!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                            string role = (RoleComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                            Dashboard dashboard = new Dashboard(); //for Admin
                            Staff_dashboard staff_Dashboard = new Staff_dashboard();                                       //for staff needed
                            if (role == "Admin")
                            {
                                this.Close(); 
                                dashboard.ShowDialog();//////////////////////////////////////////////////////////////////////
                            }
                            else if(role == "Staff")
                            {
                                this.Close(); 
                                staff_Dashboard.ShowDialog(); //here open staff dashboard

                            }
                            else if (role == "Manager")
                            {
                                this.Close();    //powerfull as admin
                                dashboard.ShowDialog();//////////////////////////////////////////////////////////////////////

                            }

                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

       
        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
    }
}
