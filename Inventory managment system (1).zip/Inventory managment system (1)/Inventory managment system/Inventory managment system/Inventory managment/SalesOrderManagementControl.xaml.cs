﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient; // Updated to Microsoft.Data.SqlClient

namespace Inventory_managment
{
    public partial class SalesOrderManagementControl : UserControl
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public SalesOrderManagementControl()
        {
            InitializeComponent();
            LoadSalesOrders();
            LoadProducts();
        }

        private void LoadSalesOrders()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT SalesOrders.SalesOrderID, CustomerName, OrderDate, Status, TotalAmount FROM SalesOrders";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    SalesOrdersDataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading sales orders: {ex.Message}");
            }
        }

        private void LoadProducts()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ProductID, Name FROM Products";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    ProductComboBox.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading products: {ex.Message}");
            }
        }

        private void LoadOrderDetails()
        {
            if (SalesOrdersDataGrid.SelectedItem is DataRowView selectedRow)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "SELECT SODetailID, ProductID, Quantity, UnitPrice, (Quantity * UnitPrice) AS TotalPrice " +
                                       "FROM SalesOrderDetails WHERE SalesOrderID = @SalesOrderID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@SalesOrderID", selectedRow["SalesOrderID"]);
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        OrderDetailsDataGrid.ItemsSource = dataTable.DefaultView;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading order details: {ex.Message}");
                }
            }
        }

        private void AddOrderButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO SalesOrders (CustomerName, OrderDate, Status, TotalAmount) VALUES (@CustomerName, @OrderDate, @Status, 0)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@CustomerName", CustomerNameTextBox.Text);
                    command.Parameters.AddWithValue("@OrderDate", OrderDatePicker.SelectedDate ?? DateTime.Now);
                    command.Parameters.AddWithValue("@Status", ((ComboBoxItem)StatusComboBox.SelectedItem)?.Content.ToString());
                    command.ExecuteNonQuery();
                }
                LoadSalesOrders();
                MessageBox.Show("Sales order added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding sales order: {ex.Message}");
            }
        }

        private void AddOrderDetailButton_Click(object sender, RoutedEventArgs e)
        {
            if (SalesOrdersDataGrid.SelectedItem is DataRowView selectedOrder &&
                ProductComboBox.SelectedItem is DataRowView selectedProduct)
            {
                if (!int.TryParse(QuantityTextBox.Text, out int quantity) || quantity <= 0)
                {
                    MessageBox.Show("Please enter a valid quantity.");
                    return;
                }

                if (!decimal.TryParse(UnitPriceTextBox.Text, out decimal unitPrice) || unitPrice <= 0)
                {
                    MessageBox.Show("Please enter a valid unit price.");
                    return;
                }

                try
                {
                    // Insert the new order detail into the database
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "INSERT INTO SalesOrderDetails (SalesOrderID, ProductID, Quantity, UnitPrice) " +
                                       "VALUES (@SalesOrderID, @ProductID, @Quantity, @UnitPrice)";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@SalesOrderID", selectedOrder["SalesOrderID"]);
                        command.Parameters.AddWithValue("@ProductID", selectedProduct["ProductID"]);
                        command.Parameters.AddWithValue("@Quantity", quantity);
                        command.Parameters.AddWithValue("@UnitPrice", unitPrice);
                        command.ExecuteNonQuery();
                    }

                    // Refresh the order details grid
                    LoadOrderDetails();

                    // Update the total amount for the sales order
                    UpdateOrderTotalAmount(selectedOrder["SalesOrderID"].ToString());

                    MessageBox.Show("Order detail added successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error adding order detail: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please select a valid sales order and product.");
            }
        }

        // Method to update the total amount for the sales order
        private void UpdateOrderTotalAmount(string salesOrderId)
        {
            try
            {
                // Get the sum of all the total prices for the order details
                decimal totalAmount = 0;
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT SUM(Quantity * UnitPrice) FROM SalesOrderDetails WHERE SalesOrderID = @SalesOrderID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@SalesOrderID", salesOrderId);
                    totalAmount = (decimal)command.ExecuteScalar();
                }

                // Update the SalesOrders table with the new total amount
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE SalesOrders SET TotalAmount = @TotalAmount WHERE SalesOrderID = @SalesOrderID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@SalesOrderID", salesOrderId);
                    command.Parameters.AddWithValue("@TotalAmount", totalAmount);
                    command.ExecuteNonQuery();
                }

                // Refresh the SalesOrders grid to show the updated total amount
                LoadSalesOrders();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating total amount: {ex.Message}");
            }
        }

        private void UpdateOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (SalesOrdersDataGrid.SelectedItem is DataRowView selectedRow)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "UPDATE SalesOrders SET CustomerName = @CustomerName, OrderDate = @OrderDate, Status = @Status WHERE SalesOrderID = @SalesOrderID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@SalesOrderID", selectedRow["SalesOrderID"]);
                        command.Parameters.AddWithValue("@CustomerName", CustomerNameTextBox.Text);
                        command.Parameters.AddWithValue("@OrderDate", OrderDatePicker.SelectedDate ?? DateTime.Now);
                        command.Parameters.AddWithValue("@Status", ((ComboBoxItem)StatusComboBox.SelectedItem)?.Content.ToString());
                        command.ExecuteNonQuery();
                    }
                    LoadSalesOrders();
                    MessageBox.Show("Sales order updated successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error updating sales order: {ex.Message}");
                }
            }
        }

        private void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (SalesOrdersDataGrid.SelectedItem is DataRowView selectedRow)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM SalesOrders WHERE SalesOrderID = @SalesOrderID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@SalesOrderID", selectedRow["SalesOrderID"]);
                        command.ExecuteNonQuery();
                    }
                    LoadSalesOrders();
                    MessageBox.Show("Sales order deleted successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting sales order: {ex.Message}");
                }
            }
        }

        private void SalesOrdersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SalesOrdersDataGrid.SelectedItem is DataRowView selectedRow)
            {
                CustomerNameTextBox.Text = selectedRow["CustomerName"].ToString();
                OrderDatePicker.SelectedDate = DateTime.TryParse(selectedRow["OrderDate"]?.ToString(), out var date) ? date : (DateTime?)null;
                StatusComboBox.SelectedItem = selectedRow["Status"].ToString();
                TotalAmountTextBox.Text = selectedRow["TotalAmount"].ToString();

                // Load order details for the selected sales order
                LoadOrderDetails();
            }
        }

        private void RemoveOrderDetailButton_Click(object sender, RoutedEventArgs e)
        {
            if (OrderDetailsDataGrid.SelectedItem is DataRowView selectedRow)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM SalesOrderDetails WHERE SODetailID = @SODetailID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@SODetailID", selectedRow["SODetailID"]);
                        command.ExecuteNonQuery();
                    }

                    // Refresh the order details grid
                    LoadOrderDetails();

                    MessageBox.Show("Order detail removed successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error removing order detail: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please select an order detail to remove.");
            }
        }
    }
}
