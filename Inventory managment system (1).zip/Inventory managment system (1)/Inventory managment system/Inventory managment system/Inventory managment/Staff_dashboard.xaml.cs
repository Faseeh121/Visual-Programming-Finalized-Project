﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Inventory_managment;
using InventoryApp;

namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for Staff_dashboard.xaml
    /// </summary>
    public partial class Staff_dashboard : Window
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;";

        public Staff_dashboard()
        {
            InitializeComponent();
        }
        private void LoadStockLevels()
        {
            string query = "SELECT ProductID, Name AS ProductName, Quantity AS StockLevel FROM Products";
            DataTable stockLevels = ExecuteQuery(query);
            StockLevelsGrid.ItemsSource = stockLevels.DefaultView;
        }

        private void LoadLowStockAlerts()
        {
            string query = "SELECT Name AS ProductName, Quantity AS StockLevel FROM Products WHERE Quantity < 10";
            DataTable lowStockProducts = ExecuteQuery(query);
            LowStockAlertsList.Items.Clear();

            foreach (DataRow row in lowStockProducts.Rows)
            {
                LowStockAlertsList.Items.Add($"{row["ProductName"]}: {row["StockLevel"]} units left");
            }
        }

        private void LoadSalesSummary()
        {
            string query = "SELECT COUNT(SalesOrderID) AS TotalOrders, SUM(TotalAmount) AS TotalSales FROM SalesOrders";
            DataTable salesSummary = ExecuteQuery(query);

            if (salesSummary.Rows.Count > 0)
            {
                TotalOrdersText.Text = $"Total Orders: {salesSummary.Rows[0]["TotalOrders"]}";
                TotalSalesText.Text = $"Total Sales: ${salesSummary.Rows[0]["TotalSales"]:0.00}";
            }
        }

        private void LoadPurchaseSummary()
        {
            string query = "SELECT COUNT(PurchaseOrderID) AS TotalPurchaseOrders, SUM(TotalAmount) AS TotalPurchases FROM PurchaseOrders";
            DataTable purchaseSummary = ExecuteQuery(query);

            if (purchaseSummary.Rows.Count > 0)
            {
                TotalPurchaseOrdersText.Text = $"Total Purchase Orders: {purchaseSummary.Rows[0]["TotalPurchaseOrders"]}";
                TotalPurchasesText.Text = $"Total Purchases: ${purchaseSummary.Rows[0]["TotalPurchases"]:0.00}";
            }
        }

        private void StartRealTimeUpdates()
        {
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(10); // Refresh every 10 seconds
            timer.Tick += (s, e) =>
            {
                LoadStockLevels();
                LoadLowStockAlerts();
                LoadSalesSummary();
                LoadPurchaseSummary();
            };
            timer.Start();
        }

        private DataTable ExecuteQuery(string query)
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(dataTable);
            }
            return dataTable;
        }

        private void Dashboard_Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("You are already on the Dashboard.");
        }

        private void Product_Button_Click(object sender, RoutedEventArgs e)
        {
            Add_Product_Window productWindow = new Add_Product_Window();
            productWindow.Show();
            this.Close();
        }

        private void Supplier_Button_Click(object sender, RoutedEventArgs e)
        {
            Admin_to_Supplier supplierWindow = new Admin_to_Supplier();
            supplierWindow.Show();
            this.Close();
        }

        private void Order_Button_Click(object sender, RoutedEventArgs e)
        {
           ///////////////////////
           //////////////////////
           /////////////////////
           ////////////////////
           Staff_sale_order_window staff_Sale_Order_ = new Staff_sale_order_window();
            staff_Sale_Order_.Show();
            this.Close();   
        }

        


        private void User_Button_Click(object sender, RoutedEventArgs e)
        {
            Staff_to_User staff_To_User = new Staff_to_User();
            staff_To_User.Show();
            this.Close();


        }


        private void Search_by_barcode_Button_Click(object sender, RoutedEventArgs e)
        {
            Searching_order searching_Order = new Searching_order();
            searching_Order.Show();
            this.Close();


        }

        private void Stock_Button_Click(object sender, RoutedEventArgs e)
        {

            Stock stock = new Stock();
            stock.Show();
            this.Close();

        }


        private void Security_Button_Click(object sender, RoutedEventArgs e)
        {

            Security security = new Security();
            security.Show();
            this.Close();

        }

        // Logout_Click
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow2 = new MainWindow();
            mainWindow2.Show();
            this.Close();
        }

    }
}
