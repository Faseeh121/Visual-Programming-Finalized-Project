﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Data.SqlClient;
using System.Net.Mail;
using System.Net;
using Newtonsoft.Json;


namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for Stock.xaml
    /// </summary>
    public partial class Stock : Window
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";
        public Stock()
        {
            InitializeComponent();
        }
        private void SyncWithShopify_Click(object sender, RoutedEventArgs e)
        {
            // Implement the logic to sync with Shopify
            MessageBox.Show("Syncing with Shopify...");
            // Example: Call Shopify API to sync inventory data
        }
        private void RecordTransaction_Click(object sender, RoutedEventArgs e)
        {
            // Logic to record stock transaction
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO StockMovements (ProductID,  MovementType, Quantity, BatchNumber, SerialNumber, MovementDate) " +
                               "VALUES (@ProductID,  @MovementType, @Quantity, @BatchNumber, @SerialNumber, @MovementDate)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ProductID", int.Parse(txtProductIDInOut.Text));

                    cmd.Parameters.AddWithValue("@MovementType", cmbTransactionTypeInOut.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Quantity", int.Parse(txtQuantityInOut.Text));
                    cmd.Parameters.AddWithValue("@BatchNumber", txtBatchNumberInOut.Text);
                    cmd.Parameters.AddWithValue("@SerialNumber", txtSerialNumberInOut.Text);
                    cmd.Parameters.AddWithValue("@MovementDate", DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadTransactions();
        }

        private void LoadTransactions()
        {
            // Logic to load transactions into lvTransactions
            List<StockMovement> transactions = new List<StockMovement>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM StockMovements";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        transactions.Add(new StockMovement
                        {
                            ProductID = reader.GetInt32(1),
                            MovementType = reader.GetString(3),
                            Quantity = reader.GetInt32(4),
                            LocationID = reader.GetInt32(2),
                            BatchNumber = reader.GetString(5),
                            SerialNumber = reader.GetString(6),
                            MovementDate = reader.GetDateTime(7)
                        });
                    }
                }
            }
            lvTransactions.ItemsSource = transactions;
        }


        private void TransferStock_Click(object sender, RoutedEventArgs e)
        {
            // Logic to transfer stock
            int productId = int.Parse(txtProductIDTransfer.Text);
            string fromLocation = txtFromLocation.Text;
            string toLocation = txtToLocation.Text;
            int quantity = int.Parse(txtQuantityTransfer.Text);

            // Insert into StockTransfers table (pseudo code)
            // Database.InsertStockTransfer(productId, fromLocation, toLocation, quantity);

            // Update StockMovements for transfer (pseudo code)
            // Database.InsertStockMovement(productId, "OUT", quantity, $"Transfer from {fromLocation} to {toLocation}");
            // Database.InsertStockMovement(productId, "IN", quantity, $"Transfer from {fromLocation} to {toLocation}");

            // Refresh the ListView (pseudo code)
            // lvTransfers.ItemsSource = Database.GetStockTransfers();
        }

        private void AdjustStock_Click(object sender, RoutedEventArgs e)
        {
            // Logic to adjust stock
            int productId = int.Parse(txtProductIDAdjustment.Text);
            int quantityAdjustment = int.Parse(txtQuantityAdjustment.Text);
            string adjustmentReason = txtAdjustmentReason.Text;

            // Insert into StockMovements table (pseudo code)
            // Database.InsertStockMovement(productId, "ADJUSTMENT", quantityAdjustment, adjustmentReason);

            // Refresh the ListView (pseudo code)
            // lvAdjustments.ItemsSource = Database.GetStockMovements();
        }

        private void LoadMovementHistory_Click(object sender, RoutedEventArgs e)
        {
            // Logic to load stock movement history into lvMovementHistory
            List<StockMovementHistory> history = new List<StockMovementHistory>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM StockMovementHistory";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        history.Add(new StockMovementHistory
                        {
                            MovementID = reader.GetInt32(0),
                            ProductID = reader.GetInt32(1),

                            MovementType = reader.GetString(3),
                            Quantity = reader.GetInt32(4),
                            BatchNumber = reader.GetString(5),
                            SerialNumber = reader.GetString(6),
                            MovementDate = reader.GetDateTime(7),
                            CreatedDate = reader.GetDateTime(8)
                        });
                    }
                }
            }
            lvMovementHistory.ItemsSource = history;
        }

        private async void SyncWithQuickBooks_Click(object sender, RoutedEventArgs e)
        {
            // Example code to sync with QuickBooks
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://quickbooks.api.intuit.com/");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "YOUR_ACCESS_TOKEN");

                var inventoryData = new
                {
                    // Prepare your inventory data here
                    // Example: ProductID, Quantity, etc.
                };

                var json = JsonConvert.SerializeObject(inventoryData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var result = await client.PostAsync("v3/company/YOUR_COMPANY_ID/inventory", content);
                result.EnsureSuccessStatusCode();
            }
        }
        private void SyncWithXero_Click(object sender, RoutedEventArgs e)
        {
            // Implement the logic to sync with Xero
            MessageBox.Show("Syncing with Xero...");
            // Example: Call Xero API to sync inventory data
        }

        private void SendNotification_Click(object sender, RoutedEventArgs e)
        {
            string emailAddress = txtEmailAddress.Text;
            string subject = "Inventory Update Notification";
            string body = "This is a notification about your inventory update.";

            SendEmailNotification(emailAddress, subject, body);
        }

        private void SendEmailNotification(string to, string subject, string body)
        {
            var smtpClient = new SmtpClient("smtp.your-email-provider.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("your-email@example.com", "your-password"),
                EnableSsl = true,
            };

            smtpClient.Send("your-email@example.com", to, subject, body);
        }

        private async void SyncWithWooCommerce_Click(object sender, RoutedEventArgs e)
        {
            // Example code to sync with WooCommerce
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://YOUR_WOOCOMMERCE_STORE/wp-json/wc/v3/");
                var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes("YOUR_CONSUMER_KEY:YOUR_CONSUMER_SECRET"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);

                var inventoryData = new
                {
                    // Prepare your inventory data here
                };

                var json = JsonConvert.SerializeObject(inventoryData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var result = await client.PutAsync("products/YOUR_PRODUCT_ID", content);
                result.EnsureSuccessStatusCode();
            }
        }

        public class StockMovement
        {
            public int ProductID { get; set; }
            public string MovementType { get; set; }
            public int Quantity { get; set; }
            public int LocationID { get; set; }
            public string BatchNumber { get; set; }
            public string SerialNumber { get; set; }
            public DateTime MovementDate { get; set; }
        }

        public class StockMovementHistory
        {
            public int MovementID { get; set; }
            public int ProductID { get; set; }

            public string MovementType { get; set; }
            public int Quantity { get; set; }
            public string BatchNumber { get; set; }
            public string SerialNumber { get; set; }
            public DateTime MovementDate { get; set; }
            public DateTime CreatedDate { get; set; }
        }

    }
}



