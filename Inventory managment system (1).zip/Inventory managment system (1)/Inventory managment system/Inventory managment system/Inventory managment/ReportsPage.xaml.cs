﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using InventoryApp;
using System.Data;
using Microsoft.Data.SqlClient;
//using System.Data.Entity;
namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for ReportsPage.xaml
    /// </summary>
    public partial class ReportsPage : Page
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public ReportsPage()
        {
            InitializeComponent();
            LoadTotalAmounts();
        }

        private void LoadTotalAmounts()
        {
            try
            {
                decimal totalPurchaseAmount = GetTotalPurchaseAmount();
                decimal totalSalesAmount = GetTotalSalesAmount();

               // TotalPurchaseAmountTextBlock.Text = totalPurchaseAmount.ToString("C"); // Format as currency
               // TotalSalesAmountTextBlock.Text = totalSalesAmount.ToString("C"); // Format as currency
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading totals: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private decimal GetTotalPurchaseAmount()
        {
            decimal total = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT SUM(TotalAmount) FROM PurchaseOrders";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    object result = command.ExecuteScalar();
                    total = result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                }
            }
            return total;
        }

        private decimal GetTotalSalesAmount()
        {
            decimal total = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT SUM(TotalAmount) FROM SalesOrders";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    object result = command.ExecuteScalar();
                    total = result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                }
            }
            return total;
        }
        private void Back_to_prev_page(object sender, RoutedEventArgs e)
        {
            Dashboard D_board = new Dashboard();
            // reportsPage.ShowsNavigationUI = true;
             this.Content = D_board;
           // this.Show();
        }
        //    private async void InventoryValuationButton_Click(object sender, RoutedEventArgs e)
        //    {
        //        using (var context = new MainWindow.MyDatabaseContext())
        //        {
        //            var inventoryValue = await context.StockItems
        //                .Select(item => new
        //                {
        //                    ItemName = item.Name,
        //                    TotalValue = item.StockLevels.Values.Sum() * item.Price // Assuming you have a Price property
        //                })
        //                .ToListAsync();

        //            string report = "Inventory Valuation:\n\n";
        //            foreach (var item in inventoryValue)
        //            {
        //                report += $"{item.ItemName}: {item.TotalValue:C}\n";
        //            }

        //            MessageBox.Show(report, "Inventory Valuation");
        //        }
        //    }

        //    private async void StockMovementReportsButton_Click(object sender, RoutedEventArgs e)
        //    {
        //        using (var context = new MainWindow.MyDatabaseContext())
        //        {
        //            var stockMovements = await context.StockMovements.ToListAsync();
        //            string report = "Stock Movement Reports:\n\n";
        //            foreach (var movement in stockMovements)
        //            {
        //                report += $"{movement.ItemName} - {movement.Quantity} ({movement.MovementType}) on {movement.Timestamp}\n";
        //            }

        //            MessageBox.Show(report, "Stock Movement Reports");
        //        }
        //    }

        //    private async void SalesPurchaseReportsButton_Click(object sender, RoutedEventArgs e)
        //    {
        //        using (var context = new MainWindow.MyDatabaseContext())
        //        {
        //            var salesData = await context.Sales.ToListAsync(); // Assuming you have a Sales DbSet
        //            var purchaseData = await context.Purchases.ToListAsync(); // Assuming you have a Purchases DbSet

        //            string report = "Sales and Purchase Reports:\n\n";
        //            report += "Sales:\n";
        //            foreach (var sale in salesData)
        //            {
        //                report += $"{sale.ItemName} - {sale.Quantity} sold on {sale.Date}\n";
        //            }

        //            report += "\nPurchases:\n";
        //            foreach (var purchase in purchaseData)
        //            {
        //                report += $"{purchase.ItemName} - {purchase.Quantity} purchased on {purchase.Date}\n";
        //            }

        //            MessageBox.Show(report, "Sales and Purchase Reports");
        //        }
        //    }

        //    private async void DemandForecastingButton_Click(object sender, RoutedEventArgs e)
        //    {
        //        using (var context = new MainWindow.MyDatabaseContext())
        //        {
        //            var historicalData = await context.StockMovements
        //                .GroupBy(m => m.ItemName)
        //                .Select(g => new
        //                {
        //                    ItemName = g.Key,
        //                    AverageMonthlySales = g.Sum(m => m.Quantity) / g.Select(m => m.Timestamp.Month).Distinct().Count()
        //                })
        //                .ToListAsync();

        //            string report = "Demand Forecasting:\n\n";
        //            foreach (var data in historicalData)
        //            {
        //                report += $"{data.ItemName}: Average Monthly Sales: {data.AverageMonthlySales}\n";
        //            }

        //            MessageBox.Show(report, "Demand Forecasting");
        //        }
        //    }


    }
}
