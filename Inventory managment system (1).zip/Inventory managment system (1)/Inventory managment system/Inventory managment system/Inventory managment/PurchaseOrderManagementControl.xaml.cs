﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace Inventory_managment
{
    public partial class PurchaseOrderManagementControl : UserControl
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public PurchaseOrderManagementControl()
        {
            InitializeComponent();
            LoadSuppliers();
            LoadProducts();
            LoadPurchaseOrders();
        }

        private void LoadSuppliers()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand("SELECT SupplierID, SupplierName FROM Suppliers", connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable supplierTable = new DataTable();
                    adapter.Fill(supplierTable);
                    SupplierComboBox.ItemsSource = supplierTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading suppliers: {ex.Message}");
            }
        }

        private void LoadProducts()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand("SELECT ProductID, Name FROM Products", connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable productTable = new DataTable();
                    adapter.Fill(productTable);
                    ProductComboBox.ItemsSource = productTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading products: {ex.Message}");
            }
        }

        private void LoadPurchaseOrders()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                SELECT 
                    PO.PurchaseOrderID, 
                    PO.SupplierID, 
                    S.SupplierName, 
                    PO.OrderDate, 
                    PO.Status, 
                    PO.TotalAmount 
                FROM 
                    PurchaseOrders PO
                INNER JOIN 
                    Suppliers S ON PO.SupplierID = S.SupplierID";

                    // Debugging: Log the query
                    Console.WriteLine(query); // or use a logging framework

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    PurchaseOrdersDataGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading purchase orders: {ex.Message}");
            }
        }

        private void AddOrderButton_Click1(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand(@"
                        INSERT INTO PurchaseOrders (SupplierID, OrderDate, Status, TotalAmount)
                        VALUES (@SupplierID, @OrderDate, @Status, @TotalAmount);
                        SELECT SCOPE_IDENTITY();", connection);

                    cmd.Parameters.AddWithValue("@SupplierID", SupplierComboBox.SelectedValue);
                    cmd.Parameters.AddWithValue("@OrderDate", OrderDatePicker.SelectedDate ?? DateTime.Now);
                    cmd.Parameters.AddWithValue("@Status", (StatusComboBox.SelectedItem as ComboBoxItem)?.Content);
                    cmd.Parameters.AddWithValue("@TotalAmount", TotalAmountTextBox.Text);

                    int orderId = Convert.ToInt32(cmd.ExecuteScalar());
                    MessageBox.Show($"Purchase order added successfully. Order ID: {orderId}");

                    LoadPurchaseOrders();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding purchase order: {ex.Message}");
            }
        }

        private void UpdateOrderButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (PurchaseOrdersDataGrid.SelectedItem is DataRowView selectedRow)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        SqlCommand cmd = new SqlCommand(@"
                            UPDATE PurchaseOrders
                            SET SupplierID = @SupplierID, OrderDate = @OrderDate, Status = @Status
                            WHERE PurchaseOrderID = @PurchaseOrderID", connection);

                        cmd.Parameters.AddWithValue("@SupplierID", SupplierComboBox.SelectedValue);
                        cmd.Parameters.AddWithValue("@OrderDate", OrderDatePicker.SelectedDate ?? DateTime.Now);
                        cmd.Parameters.AddWithValue("@Status", (StatusComboBox.SelectedItem as ComboBoxItem)?.Content);
                        cmd.Parameters.AddWithValue("@PurchaseOrderID", selectedRow["PurchaseOrderID"]);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Purchase order updated successfully.");

                        LoadPurchaseOrders();
                    }
                }
                else
                {
                    MessageBox.Show("Please select an order to update.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating purchase order: {ex.Message}");
            }
        }

        private void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (PurchaseOrdersDataGrid.SelectedItem is DataRowView selectedRow)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        SqlCommand cmd = new SqlCommand(@"
                            DELETE FROM PurchaseOrders
                            WHERE PurchaseOrderID = @PurchaseOrderID", connection);

                        cmd.Parameters.AddWithValue("@PurchaseOrderID", selectedRow["PurchaseOrderID"]);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Purchase order deleted successfully.");

                        LoadPurchaseOrders();
                    }
                }
                else
                {
                    MessageBox.Show("Please select an order to delete.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting purchase order: {ex.Message}");
            }
        }

        private void AddToOrderButton_Click1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (PurchaseOrdersDataGrid.SelectedItem is DataRowView selectedRow)
                {
                    // Validate Quantity and Unit Price inputs
                    if (string.IsNullOrWhiteSpace(QuantityTextBox.Text) || string.IsNullOrWhiteSpace(UnitPriceTextBox.Text))
                    {
                        MessageBox.Show("Please enter valid values for Quantity and Unit Price.", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    // Parse Quantity and Unit Price
                    if (!int.TryParse(QuantityTextBox.Text, out int quantity) || !decimal.TryParse(UnitPriceTextBox.Text, out decimal unitPrice))
                    {
                        MessageBox.Show("Please enter valid numeric values for Quantity and Unit Price.", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        SqlCommand cmd = new SqlCommand(@"
                    INSERT INTO PurchaseOrderDetails (PurchaseOrderID, ProductID, Quantity, UnitPrice)
                    VALUES (@PurchaseOrderID, @ProductID, @Quantity, @UnitPrice)", connection);

                        cmd.Parameters.AddWithValue("@PurchaseOrderID", selectedRow["PurchaseOrderID"]);
                        cmd.Parameters.AddWithValue("@ProductID", ProductComboBox.SelectedValue);
                        cmd.Parameters.AddWithValue("@Quantity", quantity);
                        cmd.Parameters.AddWithValue("@UnitPrice", unitPrice);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Product added to order successfully.");

                        // Refresh the order details grid after adding
                        LoadOrderDetails(Convert.ToInt32(selectedRow["PurchaseOrderID"]));
                    }
                }
                else
                {
                    MessageBox.Show("Please select an order to add products to.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding product to order: {ex.Message}");
            }
        }

        private void PurchaseOrdersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PurchaseOrdersDataGrid.SelectedItem is DataRowView selectedRow)
            {
                try
                {
                    // Set SupplierComboBox to the selected SupplierID
                    if (selectedRow.Row.Table.Columns.Contains("SupplierID"))
                    {
                        SupplierComboBox.SelectedValue = selectedRow["SupplierID"];
                    }

                    // Set OrderDatePicker to the selected OrderDate
                    if (selectedRow.Row.Table.Columns.Contains("OrderDate"))
                    {
                        OrderDatePicker.SelectedDate = selectedRow["OrderDate"] != DBNull.Value
                            ? Convert.ToDateTime(selectedRow["OrderDate"])
                            : (DateTime?)null;
                    }

                    // Set StatusComboBox to the selected Status
                    if (selectedRow.Row.Table.Columns.Contains("Status"))
                    {
                        StatusComboBox.Text = selectedRow["Status"]?.ToString() ?? string.Empty;
                    }

                    // Load order details for the selected PurchaseOrderID
                    if (selectedRow.Row.Table.Columns.Contains("PurchaseOrderID"))
                    {
                        int purchaseOrderId = Convert.ToInt32(selectedRow["PurchaseOrderID"]);
                        LoadOrderDetails(purchaseOrderId);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading order details: {ex.Message}");
                }
            }
        }

        private void RemoveOrderDetailButton_Click1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (OrderDetailsDataGrid.SelectedItem is DataRowView selectedRow)
                {
                    int orderDetailId = Convert.ToInt32(selectedRow["PODetailID"]);

                    MessageBoxResult result = MessageBox.Show(
                        "Are you sure you want to remove this item from the order?",
                        "Confirm Removal",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question
                    );

                    if (result == MessageBoxResult.Yes)
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();

                            // Delete the selected order detail
                            SqlCommand cmd = new SqlCommand(
                                "DELETE FROM PurchaseOrderDetails WHERE PODetailID = @PODetailID",
                                connection
                            );
                            cmd.Parameters.AddWithValue("@PODetailID", orderDetailId);
                            cmd.ExecuteNonQuery();

                            MessageBox.Show("Item removed from the order successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                            // Refresh the order details grid
                            LoadOrderDetails(Convert.ToInt32(selectedRow["PurchaseOrderID"]));
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select an item to remove.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error removing item from the order: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadOrderDetails(int purchaseOrderId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                        SELECT 
                            POD.PODetailID, 
                            P.Name AS ProductName, 
                            POD.Quantity, 
                            POD.UnitPrice, 
                            (POD.Quantity * POD.UnitPrice) AS Total 
                        FROM 
                            PurchaseOrderDetails POD
                        INNER JOIN 
                            Products P ON POD.ProductID = P.ProductID
                        WHERE 
                            POD.PurchaseOrderID = @PurchaseOrderID";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@PurchaseOrderID", purchaseOrderId);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Bind the DataTable to the DataGrid
                    OrderDetailsDataGrid.ItemsSource = dt.DefaultView;

                    // Check if no rows were returned
                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No order details found for the selected order.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading order details: {ex.Message}");
            }
        }
    }
}