﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using InventoryApp;

namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for Admin_to_User.xaml
    /// </summary>
    public partial class Admin_to_User : Window
    {


        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";
        public Admin_to_User()
        {
            InitializeComponent();
        }
        private void back_Click(object sender, RoutedEventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Close();
        }
        private void AddUsers_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string passwordHash = HashPassword(txtPassword.Password); // Implement a method to hash the password
            string role = (cmbRole.SelectedItem as ComboBoxItem)?.Content.ToString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Users (Username, PasswordHash, Role) VALUES (@Username, @PasswordHash, @Role)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@PasswordHash", passwordHash);
                command.Parameters.AddWithValue("@Role", role);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            ViewUsers_Click(sender, e); // Refresh the user list
        }

        private void UpdateUser_Click(object sender, RoutedEventArgs e)
        {
            if (lvUsers.SelectedItem is User selectedUser)
            {
                string username = txtUsername.Text;
                string passwordHash = HashPassword(txtPassword.Password); // Hash the new password
                string role = (cmbRole.SelectedItem as ComboBoxItem)?.Content.ToString();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Users SET Username = @Username, PasswordHash = @PasswordHash, Role = @Role WHERE UserID = @User ID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@PasswordHash", passwordHash);
                    command.Parameters.AddWithValue("@Role", role);
                    command.Parameters.AddWithValue("@User ID", selectedUser.UserID);

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }

                ViewUsers_Click(sender, e); // Refresh the user list
            }
            else
            {
                MessageBox.Show("Please select a user to update.");
            }
        }

        private void RemoveUser_Click(object sender, RoutedEventArgs e)
        {
            if (lvUsers.SelectedItem is User selectedUser)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Users WHERE UserID = @User ID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@User ID", selectedUser.UserID);

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }

                ViewUsers_Click(sender, e); // Refresh the user list
            }
            else
            {
                MessageBox.Show("Please select a user to remove.");
            }
        }

        private void ViewUsers_Click(object sender, RoutedEventArgs e)
        {
            List<User> users = new List<User>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID, Username, Role, CreatedAt FROM Users";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    users.Add(new User
                    {
                        UserID = reader.GetInt32(0),
                        Username = reader.GetString(1),
                        Role = reader.GetString(2),
                        CreatedAt = reader.GetDateTime(3)
                    });
                }
                connection.Close();
            }
            lvUsers.ItemsSource = users; // Bind the list of users to the ListView
        }

        private string HashPassword(string password)
        {
            // Implement password hashing logic here
            return password; // Placeholder, replace with actual hashing
        }
    }

    public class User
    {
        public int UserID { get; set; }
        public string Username { get; set; }
        public string Role { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}

