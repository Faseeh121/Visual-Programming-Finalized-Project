﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using InventoryApp;

using System.Data;
using Microsoft.Data.SqlClient;
namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for ReportsPageWindow.xaml
    /// </summary>
    public partial class ReportsPageWindow : Window
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public ReportsPageWindow()
        {
            InitializeComponent();
            LoadTotalAmounts();
        }

        private void LoadTotalAmounts()
        {
            try
            {
                decimal totalPurchaseAmount = GetTotalPurchaseAmount();
                decimal totalSalesAmount = GetTotalSalesAmount();

                TotalPurchaseAmountTextBlock.Text = totalPurchaseAmount.ToString("C"); // Format as currency
                TotalSalesAmountTextBlock.Text = totalSalesAmount.ToString("C"); // Format as currency
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading totals: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private decimal GetTotalPurchaseAmount()
        {
            decimal total = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT SUM(TotalAmount) FROM PurchaseOrders";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    object result = command.ExecuteScalar();
                    total = result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                }
            }
            return total;
        }

        private decimal GetTotalSalesAmount()
        {
            decimal total = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT SUM(TotalAmount) FROM SalesOrders";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    object result = command.ExecuteScalar();
                    total = result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                }
            }
            return total;
        }
        private void Back_to_prev_page(object sender, RoutedEventArgs e)
        {
            
             Dashboard dashboard = new Dashboard();
            dashboard.Show(); // Open the Dashboard window
            this.Close();     // Close the current window (if needed)
        }

        

    }
}
