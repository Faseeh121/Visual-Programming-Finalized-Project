﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Data.SqlClient;
using System.Data;
using InventoryApp;
namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for Admin_to_Supplier.xaml
    /// </summary>
    public partial class Admin_to_Supplier : Window
    {
       // private const string V = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private DataTable table;
        //public DataTable table;
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public Admin_to_Supplier()
        {
            
            InitializeComponent();
            // Initialize connection and adapter
        //    connection = new SqlConnection(@"Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True");
        //    adapter = new SqlDataAdapter("SELECT * FROM Suppliers", connection);
        //    table = new DataTable();
        ////    // Load data into the datagrid
        //    adapter.Fill(table);
        //   SuppliersDataGrid.ItemsSource = table.DefaultView;
        //
        }

        private void AddSupplier_Click(object sender, RoutedEventArgs e)
        {
            // Insert new supplier into database
            // string SupplierName = txtName.Text;
            //string ContactName = SKUTextBox.Text;
            //string category = CategoryTextBox.Text;
            //int quantity;
            //decimal unitPrice;
            //string barcode = BarcodeTextBox.Text;
            //try
            //{
            //    using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connection))
            //    {
            //        string query = "INSERT INTO Suppliers (SupplierName, ContactName, Phone, Email, Address ) " +
            //                      "VALUES (@SupplierName, @ContactName, @Phone, @Email, @Address)";
            //        using (SqlCommand command = new SqlCommand(query, connection))
            //        {
            //            command.Parameters.AddWithValue("@SupplierName", txtName.Text);
            //            command.Parameters.AddWithValue("@ContactName", txtContactName.Text);
            //            command.Parameters.AddWithValue("@Phone", txtPhone.Text);
            //            command.Parameters.AddWithValue("@Email", txtEmail.Text);
            //            command.Parameters.AddWithValue("@Address", txtAddress.Text);

            //            connection.Open();
            //            command.ExecuteNonQuery();
            //            connection.Close();

            //        // Refresh datagrid
            //       // adapter.Fill(table);
            //       // SuppliersDataGrid.ItemsSource = table.DefaultView;

            //        // Clear input fields
            //        txtName.Text = "";
            //        txtContactName.Text = "";
            //        txtPhone.Text = "";
            //        txtEmail.Text = ""; txtAddress.Text = "";

            //        MessageBox.Show("Supplier added successfully!");
            //        }
            //    }

            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Error: " + ex.Message);
            //}
            try
            {
                using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Suppliers (SupplierName, ContactName, Phone, Email, Address) " +
                                   "VALUES (@SupplierName, @ContactName, @Phone, @Email, @Address)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupplierName", txtName.Text);
                        command.Parameters.AddWithValue("@ContactName", txtContactName.Text);
                        command.Parameters.AddWithValue("@Phone", txtPhone.Text);
                        command.Parameters.AddWithValue("@Email", txtEmail.Text);
                        command.Parameters.AddWithValue("@Address", txtAddress.Text);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Supplier added successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        ClearFields();
                        LoadSuppliers();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private int selectedSupplierId = -1;
        private void UpdateSupplier_Click(object sender, RoutedEventArgs e)
        {
            // Implementation for updating supplier details
            if (selectedSupplierId == -1)
            {
                MessageBox.Show("Please select a supplier to update.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE Suppliers SET SupplierName = @SupplierName, ContactName = @ContactName, Phone = @Phone, Email = @Email, Address = @Address " +
                                   "WHERE SupplierID = @SupplierID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupplierID", selectedSupplierId);
                        command.Parameters.AddWithValue("@SupplierName", txtName.Text);
                        command.Parameters.AddWithValue("@ContactName", txtContactName.Text);
                        command.Parameters.AddWithValue("@Phone", txtPhone.Text);
                        command.Parameters.AddWithValue("@Email", txtEmail.Text);
                        command.Parameters.AddWithValue("@Address", txtAddress.Text);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Supplier updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        ClearFields();
                        LoadSuppliers();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteSupplier_Click(object sender, RoutedEventArgs e)
        {
            // Implementation for deleting a supplier
            if (selectedSupplierId == -1)
            {
                MessageBox.Show("Please select a supplier to delete.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            MessageBoxResult result = MessageBox.Show("Are you sure you want to delete this supplier?",
                                                      "Confirm Deletion", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM Suppliers WHERE SupplierID = @SupplierID";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@SupplierID", selectedSupplierId);

                            command.ExecuteNonQuery();
                            MessageBox.Show("Supplier deleted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                            ClearFields();
                            LoadSuppliers();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void ViewSuppliers_Click(object sender, RoutedEventArgs e)
        {
            // Implementation for viewing suppliers
            LoadSuppliers();
        }

        private void SuppliersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Implementation for handling selection change in the DataGrid
        }

        private void LoadSuppliers()
        {
            try
            {
                using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Suppliers";
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable suppliersTable = new DataTable();
                        adapter.Fill(suppliersTable);
                        SuppliersDataGrid.ItemsSource = suppliersTable.DefaultView;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SuppliersDataGrid_SelectionChanged1(object sender, SelectionChangedEventArgs e)
        {
            if (SuppliersDataGrid.SelectedItem is DataRowView row)
            {
                selectedSupplierId = Convert.ToInt32(row["SupplierID"]);
                txtName.Text = row["SupplierName"].ToString();
                txtContactName.Text = row["ContactName"].ToString();
                txtPhone.Text = row["Phone"].ToString();
                txtEmail.Text = row["Email"].ToString();
                txtAddress.Text = row["Address"].ToString();
            }
        }
        private void ClearFields()
        {
            txtName.Clear();
            txtContactName.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            selectedSupplierId = -1;
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
            Dashboard dashboard = new Dashboard();
            dashboard.Show(); // Open the Dashboard window
            this.Close();     // Close the current window (if needed)
        }

    }
}
