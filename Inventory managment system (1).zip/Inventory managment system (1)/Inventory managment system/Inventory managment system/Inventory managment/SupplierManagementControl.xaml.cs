﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Data.SqlClient;
//using System.Data.SqlClient;
namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for SupplierManagementControl.xaml
    /// </summary>
    public partial class SupplierManagementControl : UserControl
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public SupplierManagementControl()
        {
            InitializeComponent();
            LoadSuppliers();
        }
        private void LoadSuppliers()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Suppliers";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    List<Supplier> suppliers = new List<Supplier>();

                    while (reader.Read())
                    {
                        suppliers.Add(new Supplier
                        {
                            SupplierID = reader.GetInt32(0),
                            SupplierName = reader.GetString(1),
                            ContactName = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                            Phone = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                            Email = reader.IsDBNull(4) ? string.Empty : reader.GetString(4),
                            Address = reader.IsDBNull(5) ? string.Empty : reader.GetString(5)
                        });
                    }

                    SuppliersDataGrid.ItemsSource = suppliers;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while loading suppliers: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Add Supplier button click event
        private void AddSupplierButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Suppliers (SupplierName, ContactName, Phone, Email, Address) VALUES (@SupplierName, @ContactName, @Phone, @Email, @Address)";
                    SqlCommand command = new SqlCommand(query, connection);

                    command.Parameters.AddWithValue("@SupplierName", SupplierNameTextBox.Text);
                    command.Parameters.AddWithValue("@ContactName", ContactNameTextBox.Text);
                    command.Parameters.AddWithValue("@Phone", PhoneTextBox.Text);
                    command.Parameters.AddWithValue("@Email", EmailTextBox.Text);
                    command.Parameters.AddWithValue("@Address", AddressTextBox.Text);

                    command.ExecuteNonQuery();
                }

                LoadSuppliers();
                MessageBox.Show("Supplier added successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while adding the supplier: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Update Supplier button click event
        private void UpdateSupplierButton_Click(object sender, RoutedEventArgs e)
        {
            if (SuppliersDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Please select a supplier to update.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Supplier selectedSupplier = (Supplier)SuppliersDataGrid.SelectedItem;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE Suppliers SET SupplierName = @SupplierName, ContactName = @ContactName, Phone = @Phone, Email = @Email, Address = @Address WHERE SupplierID = @SupplierID";
                    SqlCommand command = new SqlCommand(query, connection);

                    command.Parameters.AddWithValue("@SupplierName", SupplierNameTextBox.Text);
                    command.Parameters.AddWithValue("@ContactName", ContactNameTextBox.Text);
                    command.Parameters.AddWithValue("@Phone", PhoneTextBox.Text);
                    command.Parameters.AddWithValue("@Email", EmailTextBox.Text);
                    command.Parameters.AddWithValue("@Address", AddressTextBox.Text);
                    command.Parameters.AddWithValue("@SupplierID", selectedSupplier.SupplierID);

                    command.ExecuteNonQuery();
                }

                LoadSuppliers();
                MessageBox.Show("Supplier updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while updating the supplier: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Delete Supplier button click event
        private void DeleteSupplierButton_Click(object sender, RoutedEventArgs e)
        {
            if (SuppliersDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Please select a supplier to delete.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Supplier selectedSupplier = (Supplier)SuppliersDataGrid.SelectedItem;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM Suppliers WHERE SupplierID = @SupplierID";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@SupplierID", selectedSupplier.SupplierID);

                    command.ExecuteNonQuery();
                }

                LoadSuppliers();
                MessageBox.Show("Supplier deleted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while deleting the supplier: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Refresh button click event
        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadSuppliers();
        }

        // Supplier selection changed event
        private void SuppliersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SuppliersDataGrid.SelectedItem != null)
            {
                Supplier selectedSupplier = (Supplier)SuppliersDataGrid.SelectedItem;
                SupplierNameTextBox.Text = selectedSupplier.SupplierName;
                ContactNameTextBox.Text = selectedSupplier.ContactName;
                PhoneTextBox.Text = selectedSupplier.Phone;
                EmailTextBox.Text = selectedSupplier.Email;
                AddressTextBox.Text = selectedSupplier.Address;
            }
        }
    }

    // Supplier model class
    public class Supplier
    {
        public int SupplierID { get; set; }
        public string SupplierName { get; set; }
        public string ContactName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
    }



}

