﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using InventoryApp;
using Microsoft.Data.SqlClient;

namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for Searching_order.xaml
    /// </summary>
    public partial class Searching_order : Window
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";
        public Searching_order()
        {
            InitializeComponent();
        }
        private void SearchOrders_Click(object sender, RoutedEventArgs e)
        {
            string barcode = txtBarcode.Text;
            List<SalesOrder> orders = GetOrdersByBarcode(barcode);
            lvOrders.ItemsSource = orders; // Bind the list of orders to the ListView
        }
        // back_Click
        private void back_Click(object sender, RoutedEventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Close();
        }
        private List<SalesOrder> GetOrdersByBarcode(string barcode)
        {
            List<SalesOrder> orders = new List<SalesOrder>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Query to find orders based on the barcode
                string query = @"
                    SELECT so.SalesOrderID, so.CustomerName, so.OrderDate, so.Status, so.TotalAmount
                    FROM SalesOrders so
                    JOIN SalesOrderDetails sod ON so.SalesOrderID = sod.SalesOrderID
                    JOIN Products p ON sod.ProductID = p.ProductID
                    WHERE p.Barcode = @Barcode";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Barcode", barcode);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    orders.Add(new SalesOrder
                    {
                        SalesOrderID = reader.GetInt32(0),
                        CustomerName = reader.GetString(1),
                        OrderDate = reader.GetDateTime(2),
                        Status = reader.GetString(3),
                        TotalAmount = reader.GetDecimal(4)
                    });
                }
                connection.Close();
            }

            return orders;
        }
    }

    public class SalesOrder
    {
        public int SalesOrderID { get; set; }
        public string CustomerName { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; }
        public decimal TotalAmount { get; set; }
    }
}

