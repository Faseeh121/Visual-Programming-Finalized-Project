﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
//
using Microsoft.Data.SqlClient;
//using System.Data.SqlClient;
namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for ReorderPointAlertsControl.xaml
    /// </summary>
    public partial class ReorderPointAlertsControl : UserControl
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public ReorderPointAlertsControl()
        {
            InitializeComponent();
            LoadReorderAlerts();
        }


        private void LoadReorderAlerts()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                        SELECT 
                            ProductID, 
                            Name, 
                            Category, 
                            Quantity, 
                            ReorderLevel 
                        FROM 
                            Products
                        WHERE 
                            Quantity < ReorderLevel";

                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    List<ReorderAlert> alerts = new List<ReorderAlert>();

                    while (reader.Read())
                    {
                        alerts.Add(new ReorderAlert
                        {
                            ProductID = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Category = reader.IsDBNull(2) ? "N/A" : reader.GetString(2),
                            Quantity = reader.GetInt32(3),
                            ReorderLevel = reader.GetInt32(4)
                        });
                    }

                    ReorderAlertsDataGrid.ItemsSource = alerts;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while loading reorder alerts: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Refresh button click event
        private void RefreshAlertsButton_Click(object sender, RoutedEventArgs e)
        {
            LoadReorderAlerts();
        }
    }

    // Model class for Reorder Alerts
    public class ReorderAlert
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public int ReorderLevel { get; set; }
    }
}

