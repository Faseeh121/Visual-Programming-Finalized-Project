﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using InventoryApp;
using Microsoft.Data.SqlClient;

namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for Staff_to_User.xaml
    /// </summary>
    public partial class Staff_to_User : Window
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public Staff_to_User()
        {
            InitializeComponent();
        }
        private void back_Click(object sender, RoutedEventArgs e)
        {
            Staff_dashboard staff_Dashboard = new Staff_dashboard();
            staff_Dashboard.Show();
            this.Close();
        }

        private void ViewUsers_Click(object sender, RoutedEventArgs e)
        {
            List<User> users = new List<User>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID, Username, Role, CreatedAt FROM Users";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    users.Add(new User
                    {
                        UserID = reader.GetInt32(0),
                        Username = reader.GetString(1),
                        Role = reader.GetString(2),
                        CreatedAt = reader.GetDateTime(3)
                    });
                }
                connection.Close();
            }
            lvUsers.ItemsSource = users; // Bind the list of users to the ListView
        }
    }
}
