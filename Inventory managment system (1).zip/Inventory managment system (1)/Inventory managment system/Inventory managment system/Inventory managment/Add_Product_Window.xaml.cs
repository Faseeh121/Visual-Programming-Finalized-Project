﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Data.SqlClient;
using System.Data;
using InventoryApp;

namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for Add_Product_Window.xaml
    /// </summary>
    public partial class Add_Product_Window : Window
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";
        private int selectedProductId = -1; // To track the selected product for update

        public Add_Product_Window()
        {
            InitializeComponent();
        }

       
        private void Add_Button_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextBox.Text;
            string sku = SKUTextBox.Text;
            string category = CategoryTextBox.Text;
            int quantity;
            decimal unitPrice;
            string barcode = BarcodeTextBox.Text;

            if (!int.TryParse(QuantityTextBox.Text, out quantity) || !decimal.TryParse(UnitPriceTextBox.Text, out unitPrice))
            {
                MessageBox.Show("Please enter valid values for Quantity and Unit Price.", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Products (Name, SKU, Category, Quantity, UnitPrice, Barcode) " +
                                   "VALUES (@Name, @SKU, @Category, @Quantity, @UnitPrice, @Barcode)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@SKU", sku);
                        command.Parameters.AddWithValue("@Category", string.IsNullOrEmpty(category) ? (object)DBNull.Value : category);
                        command.Parameters.AddWithValue("@Quantity", quantity);
                        command.Parameters.AddWithValue("@UnitPrice", unitPrice);
                        command.Parameters.AddWithValue("@Barcode", string.IsNullOrEmpty(barcode) ? (object)DBNull.Value : barcode);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Product added successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        // Log the action
                        LogAction(1, "Add", "Products", $"Added product: {name} (SKU: {sku})");

                        ClearFields();
                        LoadProducts();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // View Products Logic
        private void ViewButton_Click(object sender, RoutedEventArgs e)
        {
            LoadProducts();
        }

        // Load Products into DataGrid
        private void LoadProducts()
        {
            try
            {
                using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ProductID, Name, SKU, Category, Quantity, UnitPrice, Barcode FROM Products";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        ProductsDataGrid.ItemsSource = dataTable.DefaultView;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Update Product Logic
        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProductId == -1)
            {
                MessageBox.Show("Please select a product to update.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string name = NameTextBox.Text;
            string sku = SKUTextBox.Text;
            string category = CategoryTextBox.Text;
            int quantity;
            decimal unitPrice;
            string barcode = BarcodeTextBox.Text;

            if (!int.TryParse(QuantityTextBox.Text, out quantity) || !decimal.TryParse(UnitPriceTextBox.Text, out unitPrice))
            {
                MessageBox.Show("Please enter valid values for Quantity and Unit Price.", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE Products SET Name = @Name, SKU = @SKU, Category = @Category, " +
                                   "Quantity = @Quantity, UnitPrice = @UnitPrice, Barcode = @Barcode WHERE ProductID = @ProductID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@SKU", sku);
                        command.Parameters.AddWithValue("@Category", string.IsNullOrEmpty(category) ? (object)DBNull.Value : category);
                        command.Parameters.AddWithValue("@Quantity", quantity);
                        command.Parameters.AddWithValue("@UnitPrice", unitPrice);
                        command.Parameters.AddWithValue("@Barcode", string.IsNullOrEmpty(barcode) ? (object)DBNull.Value : barcode);
                        command.Parameters.AddWithValue("@ProductID", selectedProductId);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Product updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        LogAction(2, "Update", "Products", $"Updated product: {name} (SKU: {sku})");

                        ClearFields();
                        LoadProducts();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Handle DataGrid Selection
        private void ProductsDataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (ProductsDataGrid.SelectedItem is DataRowView row)
            {
                selectedProductId = Convert.ToInt32(row["ProductID"]);
                NameTextBox.Text = row["Name"].ToString();
                SKUTextBox.Text = row["SKU"].ToString();
                CategoryTextBox.Text = row["Category"].ToString();
                QuantityTextBox.Text = row["Quantity"].ToString();
                UnitPriceTextBox.Text = row["UnitPrice"].ToString();
                BarcodeTextBox.Text = row["Barcode"].ToString();
            }
        }
        //Delete Product
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProductId == -1)
            {
                MessageBox.Show("Please select a product to delete.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            MessageBoxResult result = MessageBox.Show("Are you sure you want to delete this product?",
                                                      "Confirm Deletion", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    using (var connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM Products WHERE ProductID = @ProductID";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@ProductID", selectedProductId);

                            command.ExecuteNonQuery();
                            MessageBox.Show("Product deleted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                            LogAction(3, "Delete", "Products", $"Deleted product with ID: {selectedProductId}");

                            ClearFields();
                            LoadProducts();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        // Clear input fields
        private void ClearFields()
        {
            NameTextBox.Text = string.Empty;
            SKUTextBox.Text = string.Empty;
            CategoryTextBox.Text = string.Empty;
            QuantityTextBox.Text = string.Empty;
            UnitPriceTextBox.Text = string.Empty;
            BarcodeTextBox.Text = string.Empty;
            selectedProductId = -1;
        }
        //////
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
            Dashboard dashboard = new Dashboard();
            dashboard.Show(); // Open the Dashboard window
            this.Close();     // Close the current window (if needed)
        }

        private void LogAction(int userId, string action, string tableAffected, string description)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO AuditLogs (UserID, Action, TableAffected, ActionTime, Description) " +
                               "VALUES (@UserID, @Action, @TableAffected, @ActionTime, @Description)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    cmd.Parameters.AddWithValue("@Action", action);
                    cmd.Parameters.AddWithValue("@TableAffected", tableAffected);
                    cmd.Parameters.AddWithValue("@ActionTime", DateTime.Now);
                    cmd.Parameters.AddWithValue("@Description", description);
                    cmd.ExecuteNonQuery();
                }
            }
        }



    }
}


