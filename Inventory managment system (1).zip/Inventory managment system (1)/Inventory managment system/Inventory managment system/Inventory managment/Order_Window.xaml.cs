﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using InventoryApp;

namespace Inventory_managment
{
    /// <summary>
    /// Interaction logic for Order_Window.xaml
    /// </summary>
    public partial class Order_Window : Window
    {
        public Order_Window()
        {
            InitializeComponent();
        }

        private void PurchaseOrderManagement_Click(object sender, RoutedEventArgs e)
        {
            FeatureContent.Content = new PurchaseOrderManagementControl();
        }

        private void SalesOrderManagement_Click(object sender, RoutedEventArgs e)
        {
            FeatureContent.Content = new SalesOrderManagementControl();
        }

        private void ReorderPointAlerts_Click(object sender, RoutedEventArgs e)
        {
            FeatureContent.Content = new ReorderPointAlertsControl();
        }

        private void SupplierManagement_Click(object sender, RoutedEventArgs e)
        {
            FeatureContent.Content = new SupplierManagementControl();
        }
        private void Back_SupplierManagement_Click(object sender, RoutedEventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show(); // Open the Dashboard window
            this.Close();     // Close the current window (if needed)
        }
    }
}
