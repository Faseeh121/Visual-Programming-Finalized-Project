﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using InventoryApp;
using Microsoft.Data.SqlClient;

namespace Inventory_managment
{
    public partial class Security : Window
    {
        private string connectionString = "Data Source=KING_MAKER\\SQLEXPRESS;Initial Catalog=I_management;Integrated Security=True;Trust Server Certificate=True";

        public Security()
        {
            InitializeComponent();
        }

        private void EncryptButton_Click(object sender, RoutedEventArgs e)
        {
            string dataToEncrypt = txtDataToEncrypt.Text;
            string key = "A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6"; // Ensure this key is 16, 24, or 32 bytes long for AES
            string encryptedData = EncryptionHelper.EncryptString(dataToEncrypt, key);
            txtEncryptedData.Text = encryptedData;
        }

        private void BackupButton_Click(object sender, RoutedEventArgs e)
        {
            BackupDatabase();
            MessageBox.Show("Database backup completed successfully.");
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Close();
        }

        private void BackupDatabase()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "BACKUP DATABASE I_management TO DISK = 'C:\\Backups\\I_management.bak'";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void RestoreButton_Click(object sender, RoutedEventArgs e)
        {
            RestoreDatabase();
            MessageBox.Show("Database restored successfully.");
        }

        private void RestoreDatabase()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "RESTORE DATABASE I_management FROM DISK = 'C:\\Backups\\I_management.bak'";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void LogAction(int userId, string action, string tableAffected, string description)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO AuditLogs (User ID, Action, TableAffected, ActionTime, Description) " +
                               "VALUES (@User ID, @Action, @TableAffected, @ActionTime, @Description)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@User ID", userId);
                    cmd.Parameters.AddWithValue("@Action", action);
                    cmd.Parameters.AddWithValue("@TableAffected", tableAffected);
                    cmd.Parameters.AddWithValue("@ActionTime", DateTime.Now);
                    cmd.Parameters.AddWithValue("@Description", description);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void LoadAuditLogs()
        {
            try
            {
                List<AuditLog> auditLogs = new List<AuditLog>();

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT UserID, Action, TableAffected, ActionTime FROM AuditLogs";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                auditLogs.Add(new AuditLog
                                {
                                    UserID = reader.GetInt32(0),
                                    Action = reader.GetString(1),
                                    TableAffected = reader.GetString(2),
                                    ActionTime = reader.GetDateTime(3)
                                });
                            }
                        }
                    }
                }

                lvAuditLogs.ItemsSource = auditLogs;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while loading audit logs: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (e.OriginalSource is TabControl tabControl)
                {
                    if (tabControl.SelectedItem is TabItem selectedTab && selectedTab.Header.ToString() == "Compliance Support")
                    {
                        LoadAuditLogs();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while switching tabs: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    public class AuditLog
    {
        public int UserID { get; set; }
        public string Action { get; set; }
        public string TableAffected { get; set; }
        public DateTime ActionTime { get; set; }
    }

    public static class EncryptionHelper
    {
        public static string EncryptString(string plainText, string key)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.GenerateIV();
                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream())
                {
                    ms.Write(aes.IV, 0, aes.IV.Length);
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
 
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(plainText);
                        }
                    }
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        public static string DecryptString(string cipherText, string key)
        {
            byte[] fullCipher = Convert.FromBase64String(cipherText);
            byte[] iv = new byte[16];
            Array.Copy(fullCipher, 0, iv, 0, iv.Length);
            byte[] cipher = new byte[fullCipher.Length - iv.Length];
            Array.Copy(fullCipher, iv.Length, cipher, 0, cipher.Length);

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = iv;
                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream(cipher))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            return sr.ReadToEnd();
                        }
                    }
                }
            }
        }
    }
}